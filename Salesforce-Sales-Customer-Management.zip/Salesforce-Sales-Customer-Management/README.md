# Salesforce Sales & Customer Management System

A Salesforce DX starter project for a small sales team. It demonstrates customer follow-up tracking using a custom object, Apex service logic, a Lightning Web Component, and a permission set.

## Business scenario

A sales representative receives leads, converts qualified prospects into accounts/contacts/opportunities, and records follow-up activities. This project adds a structured **Customer Follow-Up** record so the team can track the next action, due date, status, and notes.

## Features included

- Custom object: `Customer_Follow_Up__c`
- Fields for subject, status, due date, priority, notes, and related account/contact/lead
- Apex service to retrieve upcoming follow-ups
- Apex test class
- Lightning Web Component: `followUpDashboard`
- Permission set: `Sales_Manager`
- Deployment-ready Salesforce DX source layout

## Standard Salesforce objects used

This project uses standard Salesforce objects:
- Lead
- Account
- Contact
- Opportunity
- Task

The custom follow-up object can relate to a Lead, Account, or Contact. The fields are optional so a record can be created before the customer is fully qualified.

## Requirements

- A Salesforce Developer Edition org or a Salesforce sandbox
- Salesforce CLI (`sf`)
- Visual Studio Code
- Salesforce Extension Pack for VS Code

## Setup

1. Unzip this repository.
2. Open the project folder in VS Code.
3. Authorize your Salesforce org:

   ```bash
   sf org login web --alias SalesCRM --instance-url https://login.salesforce.com
   ```

   For a sandbox, use `https://test.salesforce.com`.

4. Deploy the project:

   ```bash
   sf project deploy start --source-dir force-app --target-org SalesCRM
   ```

5. Run Apex tests:

   ```bash
   sf apex run test --target-org SalesCRM --wait 10
   ```

6. Open the org:

   ```bash
   sf org open --target-org SalesCRM
   ```

## Add the Lightning Web Component to an app

After deployment:
1. Open **Setup → Lightning App Builder**.
2. Create or edit a Lightning App Page.
3. Find **Follow Up Dashboard** in the component list.
4. Drag it onto the page and save/activate the page.

## Suggested demo workflow

1. Create a Lead in Salesforce.
2. Create a Customer Follow-Up record and relate it to the Lead.
3. Set a due date, priority, and status.
4. Open the Follow Up Dashboard component to see upcoming follow-ups.
5. Mark the follow-up complete by updating its status.

## GitHub upload

Create an empty GitHub repository, then run these commands from this project folder:

```bash
git init
git add .
git commit -m "Initial Salesforce CRM project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPOSITORY.git
git push -u origin main
```

Replace the URL with your own repository URL. Never commit Salesforce passwords, access tokens, private keys, or `.env` files.

## Next improvements

- Add Salesforce Flow automation for overdue follow-up reminders.
- Add reports for follow-ups by status and priority.
- Add a dashboard for open opportunities and expected revenue.
- Add validation rules and role-based access.
- Add a lead qualification and conversion process.

## Important

This is a starter implementation, not a preconfigured live Salesforce org. Deploy it to your own Developer Edition org, test it, and customize it before presenting it as completed work.
