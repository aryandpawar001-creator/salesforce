import { LightningElement, wire } from 'lwc';
import getUpcomingFollowUps from '@salesforce/apex/CustomerFollowUpService.getUpcomingFollowUps';

const COLUMNS = [
    { label: 'Follow-Up', fieldName: 'Name' },
    { label: 'Subject', fieldName: 'Subject__c' },
    { label: 'Status', fieldName: 'Status__c' },
    { label: 'Priority', fieldName: 'Priority__c' },
    { label: 'Due Date', fieldName: 'Due_Date__c', type: 'date' }
];

export default class FollowUpDashboard extends LightningElement {
    columns = COLUMNS;

    @wire(getUpcomingFollowUps)
    followUps;

    get error() {
        return Boolean(this.followUps?.error);
    }

    get rows() {
        return this.followUps?.data ?? [];
    }

    get hasRecords() {
        return this.rows.length > 0;
    }
}
